function run_bvp()
  [x, y] = bvp(1,1);
  plot(x, y);

end
